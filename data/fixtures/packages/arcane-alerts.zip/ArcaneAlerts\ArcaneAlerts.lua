-- Arcane Alerts fixture
print('Arcane Alerts')
